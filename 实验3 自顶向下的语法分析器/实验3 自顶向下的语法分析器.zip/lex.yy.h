#include <stdio.h>
#include <stdlib.h>


#define ID_TKN      500
#define NUM_TKN     510

#define RELOP_TKN   520
#define RELOP_LT    521
#define RELOP_LE    522
#define RELOP_EQ    523
#define RELOP_NE    524
#define RELOP_GT    525
#define RELOP_GE    526


#define IF_TKN      610
#define ELSE_TKN    612
#define BREAK_TKN   630
#define WHILE_TKN   631
#define DO_TKN      632





